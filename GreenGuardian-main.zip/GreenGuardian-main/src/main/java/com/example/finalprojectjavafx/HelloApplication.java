package com.example.finalprojectjavafx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;

import javafx.stage.Stage;

import java.io.IOException;


public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException{

        Parent root = FXMLLoader.load(getClass().getResource("Define.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Tree Care Analyser");
        stage.setResizable(false);
        stage.getIcons().add(new Image(getClass().getResource("/com/example/finalprojectjavafx/plant.png").toExternalForm()));
        stage.show();

    }

    public static void main(String[] args) {
        launch(args);
    }
}